// Holds one live connection to the relay and hands each message to the service worker.
let socket = null;
let topic = null;
let retry = 1000;

function connect() {
  if (!topic) return;
  socket = new WebSocket(`wss://ntfy.sh/${topic}/ws`);
  socket.onopen = () => { retry = 1000; };
  socket.onmessage = (e) => {
    try {
      const m = JSON.parse(e.data);
      if (m.event === "message") chrome.runtime.sendMessage({ kind: "relay", message: m });
    } catch {}
  };
  socket.onclose = () => {
    socket = null;
    setTimeout(connect, retry);
    retry = Math.min(retry * 2, 60000);
  };
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.kind !== "listen" || !msg.topic) return;
  if (msg.topic === topic && socket) return;
  topic = msg.topic;
  if (socket) socket.close(); else connect();
});

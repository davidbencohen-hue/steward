// Steward Price Agent: waits for price requests from Steward, searches each store in this
// signed-in Chrome, and sends the top results back, encrypted. See relay.js for the wire format.
importScripts("relay.js", "extract.js");

const VERSION = chrome.runtime.getManifest().version;
const STORES = {
  heb: { name: "H-E-B", warm: "https://www.heb.com/", search: (q) => `https://www.heb.com/search?q=${encodeURIComponent(q)}` },
  target: { name: "Target", search: (q) => `https://www.target.com/s?searchTerm=${encodeURIComponent(q)}` },
  walmart: { name: "Walmart", search: (q) => `https://www.walmart.com/search?q=${encodeURIComponent(q)}` },
  amazon: { name: "Amazon", search: (q) => `https://www.amazon.com/s?k=${encodeURIComponent(q)}` },
  wholefoods: { name: "Whole Foods", search: (q) => `https://www.amazon.com/s?k=${encodeURIComponent(q)}&i=wholefoods` },
};
const MAX_AGE_SECONDS = 6 * 3600; // Requests older than this are skipped when the computer wakes up.

// ---------- settings and log ----------

async function settings() {
  const s = await chrome.storage.local.get(["agentId", "agentName", "stores", "visible"]);
  if (!s.agentId) {
    s.agentId = crypto.randomUUID();
    await chrome.storage.local.set({ agentId: s.agentId });
  }
  if (!s.agentName) {
    const platform = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || "";
    s.agentName = /mac/i.test(platform) ? "Chrome on Mac" : /win/i.test(platform) ? "Chrome on PC" : "Chrome";
  }
  s.stores = s.stores || Object.keys(STORES);
  return s;
}

async function log(line) {
  const { history = [] } = await chrome.storage.local.get("history");
  history.unshift({ at: Date.now(), line });
  await chrome.storage.local.set({ history: history.slice(0, 30) });
}

// ---------- listening ----------
// An offscreen page holds a live connection to the relay, so requests arrive within a second.
// A one-minute alarm restarts it if Chrome closed it and catches up on anything missed.

async function ensureListener() {
  const pairing = await loadPairing();
  if (!pairing) return;
  const has = await chrome.offscreen.hasDocument();
  if (!has) {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["WORKERS"],
      justification: "Keeps a connection open to receive price requests from Steward.",
    });
  }
  chrome.runtime.sendMessage({ kind: "listen", topic: pairing.topic }).catch(() => {});
}

async function catchUp() {
  const pairing = await loadPairing();
  if (!pairing) return;
  try {
    const { lastSeen } = await chrome.storage.local.get("lastSeen");
    for (const m of await poll(pairing.topic, lastSeen || "1h")) await handle(m);
  } catch (e) {
    console.warn("catch up failed", e);
  }
}

chrome.runtime.onInstalled.addListener(() => { chrome.alarms.create("tick", { periodInMinutes: 1 }); ensureListener(); });
chrome.runtime.onStartup.addListener(() => { chrome.alarms.create("tick", { periodInMinutes: 1 }); ensureListener(); catchUp(); });
chrome.alarms.onAlarm.addListener(() => { ensureListener(); catchUp(); });

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg.kind === "relay") handle(msg.message);
  if (msg.kind === "paired") { ensureListener(); catchUp(); }
  if (msg.kind === "test") { hunt({ id: "test-" + Date.now(), query: msg.query, stores: msg.stores, limit: 3 }, null).then(reply); return true; }
  return false;
});

// ---------- handling ----------

const working = new Set();
const seenNow = new Set();

async function handle(m) {
  if (!m || m.event !== "message" || seenNow.has(m.id)) return;
  seenNow.add(m.id);
  const { done = [] } = await chrome.storage.local.get("done");
  if (done.includes(m.id)) return;
  await chrome.storage.local.set({ done: [m.id, ...done].slice(0, 200), lastSeen: m.id });

  const pairing = await loadPairing();
  if (!pairing) return;
  const body = await open(pairing.key, m.message);
  if (!body) return;
  const me = await settings();
  const agent = { id: me.agentId, name: me.agentName, version: VERSION };

  if (body.type === "ping") {
    await publish(pairing.topic, pairing.key, { type: "pong", id: body.id, agent, stores: me.stores });
    await log("Answered a connection test from Steward");
    return;
  }
  if (body.type !== "request") return;
  if (Date.now() / 1000 - m.time > MAX_AGE_SECONDS || working.has(body.id)) return;

  // With Steward Price Agent on more than one computer, only the first to answer does the work.
  await new Promise((r) => setTimeout(r, Math.random() * 1200));
  try {
    const later = await poll(pairing.topic, m.id);
    for (const other of later) {
      const b = await open(pairing.key, other.message);
      if (b && b.type === "ack" && b.id === body.id && b.agent && b.agent.id !== me.agentId) {
        await log(`"${body.query}": ${b.agent.name} is already on it`);
        return;
      }
    }
  } catch {}

  working.add(body.id);
  const stores = (body.stores && body.stores.length ? body.stores : Object.keys(STORES)).filter((s) => STORES[s] && me.stores.includes(s));
  await publish(pairing.topic, pairing.key, { type: "ack", id: body.id, agent, stores });
  await log(`Searching "${body.query}" at ${stores.map((s) => STORES[s].name).join(", ")}`);
  try {
    await hunt({ ...body, stores }, async (result) => publish(pairing.topic, pairing.key, { type: "result", id: body.id, agent, ...result }));
  } finally {
    working.delete(body.id);
    await publish(pairing.topic, pairing.key, { type: "done", id: body.id, agent }).catch(() => {});
  }
}

// ---------- searching ----------

/** Searches every store at once. Calls `send` with each store's result as it comes in. Returns all results. */
async function hunt(req, send) {
  const me = await settings();
  const stores = (req.stores && req.stores.length ? req.stores : me.stores).filter((s) => STORES[s]);
  // A window of its own, out of the way. Minimized first; a store that comes back empty is tried
  // once more in a small visible window, since some pages only draw while they can be seen.
  const results = await withWindow(me.visible ? "normal" : "minimized", (windowId) =>
    Promise.all(stores.map((store) => searchStore(windowId, store, req.query, req.limit || 3)))
  );
  const retry = results.filter((r) => r.status === "empty" || r.status === "error").map((r) => r.store);
  if (retry.length && !me.visible) {
    const again = await withWindow("normal", (windowId) =>
      Promise.all(retry.map((store) => searchStore(windowId, store, req.query, req.limit || 3)))
    );
    for (const r of again) if (r.status === "ok") results[results.findIndex((x) => x.store === r.store)] = r;
  }
  for (const r of results) {
    if (send) await send(r).catch((e) => console.warn("send failed", e));
  }
  const ok = results.filter((r) => r.status === "ok").length;
  await log(`"${req.query}": prices from ${ok} of ${results.length} stores`);
  return results;
}

async function withWindow(state, work) {
  const opts = state === "minimized"
    ? { url: "about:blank", focused: false, state: "minimized" }
    : { url: "about:blank", focused: false, width: 520, height: 640, left: 0, top: 0 };
  const win = await chrome.windows.create(opts);
  try {
    return await work(win.id);
  } finally {
    chrome.windows.remove(win.id).catch(() => {});
  }
}

function loaded(tabId, timeoutMs = 25000) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => { chrome.tabs.onUpdated.removeListener(on); resolve(false); }, timeoutMs);
    function on(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(on);
        resolve(true);
      }
    }
    chrome.tabs.onUpdated.addListener(on);
  });
}

async function searchStore(windowId, store, query, limit) {
  const s = STORES[store];
  const searchURL = s.search(query);
  const base = { store, storeName: s.name, searchURL, at: Date.now() };
  let tab;
  try {
    // H-E-B turns away a search that doesn't start on its own pages, so open its home page first.
    tab = await chrome.tabs.create({ windowId, url: s.warm || searchURL, active: false });
    await loaded(tab.id);
    if (s.warm) {
      await new Promise((r) => setTimeout(r, 1500));
      await chrome.tabs.update(tab.id, { url: searchURL });
      await new Promise((r) => setTimeout(r, 300));
      await loaded(tab.id);
    }
    const [run] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: stewardExtract, args: [store, limit] });
    const r = run && run.result;
    if (!r) return { ...base, status: "error", note: "The page could not be read", items: [] };
    if (r.blocked) return { ...base, status: "blocked", note: `${s.name} asked whether this is a robot. Open ${s.name} in Chrome once, then try again.`, items: [] };
    if (!r.items.length) return { ...base, status: "empty", note: "No results found", items: [] };
    return { ...base, status: "ok", items: r.items };
  } catch (e) {
    return { ...base, status: "error", note: String(e && e.message || e).slice(0, 140), items: [] };
  } finally {
    if (tab) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

// The pairing code, the encryption and the relay. Shared by the service worker and the popup.
//
// Steward and this extension share one secret: the pairing code shown in Steward's Settings.
// Every message is sealed with AES-256-GCM using it, so the relay (ntfy.sh) only ever carries
// unreadable text on a topic name that is itself derived from the secret.
//
// Wire format of one relay message: "stw1:" + base64( 12-byte nonce | ciphertext | 16-byte tag )
// which is exactly CryptoKit's AES.GCM.SealedBox.combined on the iPhone.

const RELAY = "https://ntfy.sh";
const PREFIX = "stw1:";

function b64urlToBytes(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}
function bytesToB64(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
function b64ToBytes(s) {
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}

/** "STW1-<base64url of 32 bytes>" → the raw key, or null. Spaces and line breaks are ignored. */
function parsePairing(code) {
  const m = /^STW1-([A-Za-z0-9_-]{43})=*$/.exec((code || "").replace(/\s+/g, ""));
  if (!m) return null;
  const raw = b64urlToBytes(m[1]);
  return raw.length === 32 ? raw : null;
}

async function topicFor(raw) {
  const label = new TextEncoder().encode("steward-topic:");
  const both = new Uint8Array(label.length + raw.length);
  both.set(label);
  both.set(raw, label.length);
  const hash = new Uint8Array(await crypto.subtle.digest("SHA-256", both));
  return "stw-" + [...hash].map((b) => b.toString(16).padStart(2, "0")).join("").slice(0, 24);
}

async function keyFor(raw) {
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}

async function seal(key, obj) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(JSON.stringify(obj))));
  const out = new Uint8Array(12 + ct.length);
  out.set(iv);
  out.set(ct, 12);
  return PREFIX + bytesToB64(out);
}

async function open(key, text) {
  if (!text || !text.startsWith(PREFIX)) return null;
  try {
    const all = b64ToBytes(text.slice(PREFIX.length));
    const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: all.subarray(0, 12) }, key, all.subarray(12));
    return JSON.parse(new TextDecoder().decode(plain));
  } catch {
    return null; // Not ours, or a different pairing code.
  }
}

async function publish(topic, key, obj) {
  const res = await fetch(`${RELAY}/${topic}`, { method: "POST", body: await seal(key, obj) });
  if (!res.ok) throw new Error("Relay said " + res.status);
  return res.json();
}

/** Messages on the topic after `since` (a message id, a unix time, or "all"). */
async function poll(topic, since) {
  const res = await fetch(`${RELAY}/${topic}/json?poll=1&since=${encodeURIComponent(since || "10m")}`);
  if (!res.ok) throw new Error("Relay said " + res.status);
  const text = await res.text();
  return text.split("\n").filter(Boolean).map((l) => JSON.parse(l)).filter((m) => m.event === "message");
}

/** Loads the saved pairing, or null when this computer isn't paired yet. */
async function loadPairing() {
  const { pairing } = await chrome.storage.local.get("pairing");
  const raw = parsePairing(pairing);
  if (!raw) return null;
  return { code: pairing, topic: await topicFor(raw), key: await keyFor(raw) };
}

// Reads the top search results off a store's search page.
// Injected into the page by the service worker; returns [{title, price, unitPrice, unit, url, sponsored}].
// Kept free of outside variables so chrome.scripting.executeScript can run it as is.
async function stewardExtract(store, limit) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const money = (s) => {
    const m = /\$\s?(\d{1,4}(?:,\d{3})*(?:\.\d{1,2})?)/.exec(s || "");
    return m ? parseFloat(m[1].replace(/,/g, "")) : null;
  };
  const UNIT = /(\$\s?\d+(?:\.\d+)?|\d+(?:\.\d+)?\s?¢)\s?\/\s?(fl\.?\s?oz|fluid ounce|ounce|oz|count|ct|each|ea|lb|pound|gal|gallon|load|roll|sheet|square foot|square feet|sq\.?\s?ft|100 sheets|1000 count)\b/i;
  const unitOf = (text) => {
    const m = UNIT.exec(text || "");
    if (!m) return {};
    let v = m[1].includes("¢") ? parseFloat(m[1]) / 100 : parseFloat(m[1].replace(/[$\s]/g, ""));
    let u = m[2].toLowerCase().replace(/\./g, "").replace(/\s+/g, " ");
    u = { "fluid ounce": "fl oz", "floz": "fl oz", ounce: "oz", ct: "count", ea: "each", pound: "lb", gallon: "gal", "sqft": "sq ft", "square foot": "sq ft", "square feet": "sq ft" }[u] || u;
    return { unitPrice: Math.round(v * 10000) / 10000, unit: u };
  };
  const clean = (s) => (s || "").replace(/\s+/g, " ").trim();
  const imageIn = (el) => {
    for (const img of el ? el.querySelectorAll("img") : []) {
      const src = img.currentSrc || img.src || img.getAttribute("data-src") || "";
      if (/^https:/.test(src) && !/sprite|icon|logo|badge|rating|star/i.test(src) && (img.naturalWidth || 100) >= 40) return src.split(" ")[0];
    }
    return null;
  };
  const climb = (el, test, max = 8) => {
    let c = el;
    for (let i = 0; i < max && c; i++) { c = c.parentElement; if (c && test(c)) return c; }
    return null;
  };
  // Wait for results to render, nudging lazy pages by scrolling.
  const ready = {
    heb: () => document.querySelector('a[href*="/product-detail/"]'),
    target: () => document.querySelector('a[href*="/p/"]') && /\$\d/.test(document.body.innerText),
    walmart: () => document.querySelector("[data-item-id]"),
    amazon: () => document.querySelector('[data-component-type="s-search-result"]'),
    wholefoods: () => document.querySelector('[data-component-type="s-search-result"]'),
  }[store];
  if (/think you were a bot|Robot Check|captcha|unusual traffic/i.test(document.body.innerText.slice(0, 3000)))
    return { blocked: true, items: [] };
  for (let i = 0; i < 24 && !(ready && ready()); i++) await sleep(500);
  window.scrollTo(0, 1200); await sleep(900); window.scrollTo(0, 0);

  let out = [];
  if (store === "amazon" || store === "wholefoods") {
    for (const c of document.querySelectorAll('[data-component-type="s-search-result"]')) {
      const title = clean([...c.querySelectorAll("h2")].map((h) => h.innerText).join(" "));
      const price = money(c.querySelector(".a-price:not(.a-text-price) .a-offscreen")?.textContent);
      const a = c.querySelector("h2 a, a.a-link-normal[href*='/dp/']");
      const sponsored = /Sponsored/i.test(c.innerText.slice(0, 200));
      if (title && price != null) out.push({ title, price, ...unitOf(c.innerText), url: a ? new URL(a.getAttribute("href"), location.origin).href.split("?")[0] : null, image: imageIn(c), sponsored });
    }
  } else if (store === "walmart") {
    for (const c of document.querySelectorAll("[data-item-id]")) {
      const t = c.querySelector('[data-automation-id="product-title"]')?.innerText || (/Information, (.*?), Price/.exec(c.innerText.replace(/\n/g, " ")) || [])[1];
      const pr = c.querySelector('[data-automation-id="product-price"]')?.innerText || c.innerText;
      const price = money((/current price[^$]*(\$[\d.,]+)/i.exec(pr) || [])[1] || (/Price (\$[\d.,]+)/.exec(c.innerText.replace(/\n/g, " ")) || [])[1] || pr);
      const a = c.querySelector('a[href*="/ip/"]');
      const sponsored = /Sponsored/i.test(c.innerText.slice(0, 200));
      if (t && price != null) out.push({ title: clean(t), price, ...unitOf(c.innerText), url: a ? new URL(a.getAttribute("href"), location.origin).href.split("?")[0] : null, image: imageIn(c), sponsored });
    }
  } else {
    // H-E-B and Target: start from each product link, climb to the card that holds its price.
    const sel = store === "heb" ? 'a[href*="/product-detail/"]' : 'a[href*="/p/"]';
    const seen = new Set();
    for (const a of document.querySelectorAll(sel)) {
      const href = new URL(a.getAttribute("href"), location.origin).href.split("?")[0].split("#")[0];
      if (seen.has(href)) continue;
      if (a.closest('[data-test*="Recommended" i], [data-test*="recommended" i], [data-test*="carousel" i]')) continue;
      const lines = a.innerText.split("\n").map(clean).filter((l) => l.length > 8 && !/\$|¢|each|out of 5|SNAP|stars|reviews/i.test(l) && !/^(buy \d|save |deal|sale\b|\d+% off)|% off/i.test(l));
      const title = lines.sort((x, y) => y.length - x.length)[0];
      if (!title) continue;
      const card = climb(a, (c) => /\$\d/.test(c.innerText) && c.querySelectorAll(sel).length <= 3);
      if (!card) continue;
      const price = money(store === "target" ? (card.querySelector('[data-test="current-price"]')?.innerText || card.innerText) : card.innerText);
      if (price == null) continue;
      seen.add(href);
      out.push({ title, price, ...unitOf(card.innerText), url: href, image: imageIn(card), sponsored: /Sponsored/i.test(card.innerText.slice(0, 120)) });
    }
  }
  // No unit price on the page: work one out from the size in the name ("150 ct", "64 fl oz", "1/2 gal").
  const sizeOf = (t) => {
    let m;
    if ((m = /(\d+(?:\.\d+)?)\s?-?\s?(?:ct|count|pk|pack|picks|pc|pieces)\b/i.exec(t))) return { n: +m[1], unit: "count" };
    if ((m = /(\d+(?:\.\d+)?)\s?-?\s?(?:fl\.?\s?oz|fluid ounces?)\b/i.exec(t))) return { n: +m[1], unit: "fl oz" };
    if (/\b(1\/2|half)[\s-]?gal(lon)?\b/i.test(t)) return { n: 64, unit: "fl oz" };
    if ((m = /(\d+(?:\.\d+)?)\s?-?\s?gal(lon)?s?\b/i.exec(t))) return { n: +m[1] * 128, unit: "fl oz" };
    if ((m = /(\d+(?:\.\d+)?)\s?-?\s?(?:oz|ounces?)\b/i.exec(t))) return { n: +m[1], unit: "oz" };
    if ((m = /(\d+(?:\.\d+)?)\s?-?\s?(?:sq\.?\s?ft|square f(?:oo|ee)t)\b/i.exec(t))) return { n: +m[1], unit: "sq ft" };
    if ((m = /(\d+(?:\.\d+)?)\s?-?\s?(?:lbs?|pounds?)\b/i.exec(t))) return { n: +m[1], unit: "lb" };
    return null;
  };
  for (const x of out) {
    if (x.unitPrice != null) continue;
    const s = sizeOf(x.title);
    if (s && s.n > 0) { x.unitPrice = Math.round((x.price / s.n) * 10000) / 10000; x.unit = s.unit; x.unitFromName = true; }
  }
  for (const x of out) if (x.title.length > 150) x.title = x.title.slice(0, 147).trimEnd() + "…";
  for (const x of out) if (x.image && x.image.length > 300) x.image = null;
  // Organic results first, then sponsored, keep page order otherwise.
  out = out.filter((x) => !x.sponsored).concat(out.filter((x) => x.sponsored));
  return { blocked: false, items: out.slice(0, limit || 3) };
}

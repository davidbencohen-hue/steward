// Reads one product page: the price you'd pay now, the unit price and the name.
// Used for Regulars, where you've picked the exact product once and Steward re-checks it.
// Injected by the service worker; returns {price, unitPrice, unit, title, regularPrice} or {blocked} or {missing}.
async function stewardProduct(store) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const money = (s) => {
    const m = /\$\s?(\d{1,4}(?:,\d{3})*(?:\.\d{1,2})?)/.exec(s || "");
    return m ? parseFloat(m[1].replace(/,/g, "")) : null;
  };
  const UNIT = /(\$\s?\d+(?:\.\d+)?|\d+(?:\.\d+)?\s?¢)\s?\/\s?(fl\.?\s?oz|fluid ounce|ounce|oz|count|ct|each|ea|lb|pound|gal|gallon|load|roll|sheet|square foot|square feet|sq\.?\s?ft)\b/i;
  const unitOf = (text) => {
    const m = UNIT.exec(text || "");
    if (!m) return {};
    const v = m[1].includes("¢") ? parseFloat(m[1]) / 100 : parseFloat(m[1].replace(/[$\s]/g, ""));
    let u = m[2].toLowerCase().replace(/\./g, "").replace(/\s+/g, " ");
    u = { "fluid ounce": "fl oz", floz: "fl oz", ounce: "oz", ct: "count", ea: "each", pound: "lb", gallon: "gal", sqft: "sq ft", "square foot": "sq ft", "square feet": "sq ft" }[u] || u;
    return { unitPrice: Math.round(v * 10000) / 10000, unit: u };
  };
  const clean = (s) => (s || "").replace(/\s+/g, " ").trim();

  // Where each store puts the price box on a product page. The first one found wins.
  const boxes = {
    target: ['[data-test="module-product-detail-price-v2"]', '[data-test="price-cdui"]', '[data-test="product-price"]'],
    walmart: ['[data-seo-id="hero-price"]', '[itemprop="price"]', '[data-testid="price-wrap"]'],
    amazon: ["#corePrice_feature_div", "#corePriceDisplay_desktop_feature_div", "#apex_desktop", "#price_inside_buybox"],
    wholefoods: ["#corePrice_feature_div", "#corePriceDisplay_desktop_feature_div", "#apex_desktop", "#price_inside_buybox"],
    heb: ['[data-qe-id="productPrice"]', '[data-qe-id="productDetailsPrice"]', '[class*="ProductPrice"]'],
  }[store] || [];

  for (let i = 0; i < 30; i++) {
    if (boxes.some((q) => document.querySelector(q) && /\$\d/.test(document.querySelector(q).innerText))) break;
    await sleep(400);
  }
  const head = document.body.innerText.slice(0, 3000);
  if (/think you were a bot|Robot Check|captcha|unusual traffic/i.test(head)) return { blocked: true };
  if (/page (isn't|is not) available|no longer available|couldn't find this page|Page Not Found/i.test(head)) return { missing: true };

  const title = clean(document.querySelector("#productTitle, h1")?.innerText).slice(0, 110);
  let box = null;
  for (const q of boxes) {
    const el = document.querySelector(q);
    if (el && /\$\d/.test(el.innerText)) { box = el; break; }
  }
  let price = null, regularPrice = null, text = "";
  if (box) {
    text = box.innerText;
    // Amazon hides the full price in .a-offscreen; elsewhere the first dollar amount is today's price.
    price = money(box.querySelector(".a-price:not(.a-text-price) .a-offscreen")?.textContent) ?? money(text);
    const reg = /(?:reg\.?|was|list(?: price)?:?|typical price:?)\s*\$\s?(\d+(?:\.\d{1,2})?)/i.exec(text.replace(/\n/g, " "));
    if (reg) regularPrice = parseFloat(reg[1]);
  }
  // Last resort: the page's own product data, then the first price after the name.
  if (price == null) {
    for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        for (const o of [].concat(JSON.parse(s.textContent)["@graph"] || JSON.parse(s.textContent))) {
          const off = [].concat(o.offers || [])[0];
          const p = off && parseFloat(off.price ?? off.lowPrice);
          if (p > 0) { price = p; break; }
        }
      } catch {}
      if (price != null) break;
    }
  }
  if (price == null) {
    const main = (document.querySelector("main") || document.body).innerText;
    const at = title ? main.indexOf(title.slice(0, 30)) : 0;
    text = main.slice(Math.max(0, at), at + 1500);
    price = money(text);
  }
  if (price == null) return { missing: true, title };
  let u = unitOf(text);
  if (u.unitPrice == null) u = unitOf((document.querySelector("main") || document.body).innerText.slice(0, 8000));
  return { price, regularPrice, title, ...u };
}

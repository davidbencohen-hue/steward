const NAMES = { heb: "H-E-B", target: "Target", walmart: "Walmart", amazon: "Amazon", wholefoods: "Whole Foods" };
const $ = (id) => document.getElementById(id);

async function render() {
  const s = await chrome.storage.local.get(["pairing", "agentName", "stores", "visible", "history"]);
  const pairing = await loadPairing();
  $("dot").classList.toggle("on", !!pairing);
  $("state").textContent = pairing ? `Paired · listening for Steward` : "Not paired";
  $("pairBox").hidden = !!pairing;
  $("unpair").hidden = !pairing;
  const platform = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || "";
  $("name").value = s.agentName || (/mac/i.test(platform) ? "Chrome on Mac" : /win/i.test(platform) ? "Chrome on PC" : "Chrome");
  $("visible").checked = !!s.visible;
  const on = s.stores || Object.keys(NAMES);
  $("stores").innerHTML = "";
  for (const [k, v] of Object.entries(NAMES)) {
    const l = document.createElement("label");
    l.innerHTML = `<input type="checkbox" data-store="${k}" ${on.includes(k) ? "checked" : ""}> ${v}`;
    $("stores").appendChild(l);
  }
  const h = s.history || [];
  $("log").innerHTML = h.length
    ? h.slice(0, 12).map((e) => `<div>${new Date(e.at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })} · ${escapeHTML(e.line)}</div>`).join("")
    : "Nothing yet.";
}

function escapeHTML(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}

$("pair").onclick = async () => {
  const code = $("code").value.replace(/\s+/g, "");
  if (!parsePairing(code)) {
    $("state").textContent = "That code doesn't look right. Copy it again from Steward.";
    return;
  }
  await chrome.storage.local.set({ pairing: code, lastSeen: null, done: [] });
  chrome.runtime.sendMessage({ kind: "paired" });
  render();
};
$("unpair").onclick = async () => { await chrome.storage.local.remove("pairing"); render(); };
$("name").onchange = () => chrome.storage.local.set({ agentName: $("name").value.trim() });
$("visible").onchange = () => chrome.storage.local.set({ visible: $("visible").checked });
$("stores").onchange = () => chrome.storage.local.set({ stores: [...document.querySelectorAll("[data-store]:checked")].map((x) => x.dataset.store) });

$("go").onclick = async () => {
  const query = $("q").value.trim();
  if (!query) return;
  $("results").textContent = "Searching…";
  const { stores } = await chrome.storage.local.get("stores");
  const results = await chrome.runtime.sendMessage({ kind: "test", query, stores: stores || Object.keys(NAMES) });
  $("results").innerHTML = (results || []).map((r) => {
    const best = r.items[0];
    if (!best) return `<div><b>${r.storeName}</b> ${escapeHTML(r.note || r.status)}</div>`;
    const unit = best.unitPrice != null ? ` · $${best.unitPrice.toFixed(3)}/${best.unit}` : "";
    return `<div><b>${r.storeName}</b> $${best.price.toFixed(2)}${unit}<br><span class="muted">${escapeHTML(best.title)}</span></div>`;
  }).join("");
  render();
};

render();
